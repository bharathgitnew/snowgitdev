{{ config(
    materialized='tel_incremental',
    incremental_strategy='merge',
    alias='MYSKILLS_COMPANY',
    unique_key = ['CompanyId']
) }}

with source_data as
(   SELECT
        KSMN_TABLE.TELKAICD AS CompanyId,
        KSMN_TABLE.SEISNE AS Name,
        KSMN_TABLE.SSRYNE AS ShortName,
        KSMN_TABLE.KUNICD AS CountryCode
        FROM {{ ref('BRONZE__TEH_REVENUE_COGS__MYSKILLS_KSMN_TABLE') }} KSMN_TABLE    
    )
,transform_data as
(
    SELECT 
        '{{ invocation_id }}' AS _AUDIT_LOG_ID,
        SHA2('hash_me') as _ROW_HASH, -- Adds column to table on full refresh.
        CompanyId,
        Name,
        ShortName,
        CountryCode
        FROM source_data
        )
,type_data as 
(
    select
        cast(_AUDIT_LOG_ID as varchar(128)) as _AUDIT_LOG_ID,
        cast(_ROW_HASH as varchar(128)) as _ROW_HASH,
        cast(COMPANYID as VARCHAR(16777216)) as COMPANYID,
        cast(NAME as VARCHAR(16777216)) as NAME,
        cast(SHORTNAME as VARCHAR(16777216)) as SHORTNAME,
        cast(COUNTRYCODE as VARCHAR(16777216)) as COUNTRYCODE
    from transform_data
    )
select * from type_data